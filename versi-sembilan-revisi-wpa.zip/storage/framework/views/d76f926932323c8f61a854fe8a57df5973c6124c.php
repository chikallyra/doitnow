<?php $__env->startSection('container'); ?>
<div class="grid grid-cols-1 gap-4 lg:grid-cols-2 lg:gap-8 pt-20">
  <div class=" items-center flex  justify-center bg-red-600 lg:h-[610px]" >
    <img src="/img/loginbanner.png" class="w-[120px] lg:w-[400px] lg:mt-14" h-70 alt="">
  </div>
  <div class="">
    <div class="flex flex-wrap items-center justify-center lg:mr-20 lg:mt-[50px]">
      <!-- alert registration success -->
      <?php if(session()->has('success')): ?>
          <div class="p-4 mb-4 mt-2 text-sm text-green-800 rounded-lg bg-green-300" role="alert">
              <?php echo e(session('success')); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
      <?php endif; ?>

      <!-- alert login failed -->
      <?php if(session()->has('loginError')): ?>
          <div class="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-300" role="alert">
              <?php echo e(session('loginError')); ?>

              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
      <?php endif; ?>

        <div class="max-w-md px-8 py-6 bg-white bg-opacity-30 border-2 border-gray-200 rounded-lg shadow-xl shadow-slate-300 sm:p-6 md:p-8 w-full mt-6 lg:ml-20 lg:w-full">
            <form class="space-y-5" action="<?php echo e(route('login.getemail')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <h5 class="text-3xl font-bold text-center pb-3 text-gray-900">Log in to Button as...</h5>
                <div>
                    <input type="email" name="email" id="email" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" placeholder="Enter your email" autofocus >
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-red-500">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Button Login -->
                <button type="submit"
                    class="w-full text-white bg-[#DD2120] font-bold hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg text-base px-5 py-2.5 text-center">Next</button>
            </form>
                <p class="text-center font-bold text-lg text-gray-400">Or</p>

                <!-- Button Login with Google -->
                <button type="submit"
                    class="flex items-start justify-center w-full text-blue-700 bg-gray-100 font-bold text-[24px] hover:bg-gray-200 focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-lg text-sm px-5 py-2.5">
                    <img src="img/google.png" class="w-5 h-5" alt="">
                    <a href="<?php echo e(route('redirect')); ?>"> Login with Google</a>
                </button>

                <div class="text-sm font-medium text-center text-gray-900">
                    Don't have an account yet? <a href="/registrasi" class="text-blue-700 hover:underline font-bold">Register
                        Now!</a>
                </div>
        </div>

    </div>
  </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\versi-sembilan-revisi-wpa\resources\views/login/index.blade.php ENDPATH**/ ?>